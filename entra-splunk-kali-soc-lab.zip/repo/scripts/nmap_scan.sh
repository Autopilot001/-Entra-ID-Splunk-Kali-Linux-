#!/usr/bin/env bash
# nmap_scan.sh — recon automation for the lab victim host.
# Usage: ./nmap_scan.sh <target_ip>
# SCOPE: only ever point this at a host you own/control on your lab network.

set -euo pipefail

TARGET="${1:?Usage: $0 <target_ip>}"
OUTDIR="./scans/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUTDIR"

echo "[*] Host discovery check"
nmap -sn "$TARGET" -oN "$OUTDIR/host_discovery.txt"

echo "[*] Top-1000-port SYN scan"
sudo nmap -sS -T4 "$TARGET" -oN "$OUTDIR/syn_scan.txt"

echo "[*] Full 65535-port SYN scan (slower)"
sudo nmap -sS -p- -T4 "$TARGET" -oN "$OUTDIR/full_scan.txt"

echo "[*] Service/version detection on discovered open ports"
OPEN_PORTS=$(grep -E '^[0-9]+/tcp\s+open' "$OUTDIR/full_scan.txt" | cut -d/ -f1 | paste -sd, -)
if [ -n "$OPEN_PORTS" ]; then
  nmap -sV -p "$OPEN_PORTS" "$TARGET" -oN "$OUTDIR/service_scan.txt"
fi

echo "[*] UDP top-50 scan"
sudo nmap -sU --top-ports 50 "$TARGET" -oN "$OUTDIR/udp_scan.txt"

echo "[+] Done. Results in $OUTDIR"
echo "[+] This traffic should now show up in Splunk under index=linux_victim — check splunk/detections/port_scan_detection.spl"
