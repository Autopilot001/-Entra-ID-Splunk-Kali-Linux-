# 01 — Lab Architecture

## Goal
Build a small, realistic environment that produces two attack telemetry streams:
1. **Identity telemetry** from Entra ID (sign-ins, risky users, MFA events).
2. **Network telemetry** from a victim host being port-scanned and brute-forced by a Kali attacker box.

Both streams land in Splunk, where you write detections and dashboards against them.

## VMs / components

| Component | Role | Suggested spec | Notes |
|---|---|---|---|
| Kali Linux | Attacker | 2 vCPU / 4GB RAM | nmap, Hydra (lab creds only), Atomic Red Team |
| Victim (Ubuntu Server) | Target | 2 vCPU / 2GB RAM | Runs SSH, a web service, Splunk Universal Forwarder |
| Splunk Enterprise | SIEM | 4 vCPU / 8GB RAM | Free Developer license (500MB/day) is enough |
| Entra ID tenant | Identity provider | Microsoft 365 / Azure free trial | Cloud-only, no extra VM needed |

Run Kali and the victim on an **internal-only / host-only virtual network** (VirtualBox host-only adapter or a dedicated Hyper-V/VMware internal switch) so scan traffic never reaches your real LAN or the internet.

## Network diagram

See the Mermaid diagram below (renders natively on GitHub).

```mermaid
flowchart LR
    subgraph Internet-facing
        Entra[Microsoft Entra ID]
    end
    subgraph Host-only lab network 192.168.56.0/24
        Kali[Kali Linux attacker\n192.168.56.10]
        Victim[Ubuntu victim + Splunk UF\n192.168.56.20]
    end
    Splunk[Splunk Enterprise\nSIEM]
    Entra -- Graph API / Cloud Services add-on --> Splunk
    Victim -- syslog / UF :9997 --> Splunk
    Kali -- nmap, Hydra, Atomic Red Team --> Victim
```

## Data flow summary

1. Entra ID generates sign-in and audit logs as users (real or simulated) authenticate.
2. The **Splunk Add-on for Microsoft Cloud Services** (or Microsoft Sentinel's Graph API connector mirrored into Splunk) pulls those logs on a schedule.
3. Kali runs reconnaissance (`nmap`) and a simulated credential attack against the victim box.
4. The victim's auth logs (`/var/log/auth.log`), firewall logs (`ufw`/`iptables`), and web server logs are forwarded via the Splunk Universal Forwarder.
5. Splunk correlates both streams, triggers saved searches / alerts, and renders them on dashboards.

Next: [`02-entra-id-setup.md`](./02-entra-id-setup.md)
