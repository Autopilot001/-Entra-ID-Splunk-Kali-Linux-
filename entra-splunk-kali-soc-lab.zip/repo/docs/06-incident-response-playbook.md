# 06 — Incident Response Playbook

A short SOC-L1-style triage playbook for the two alert chains this lab produces. Use it to practice the analyst workflow: **triage → scope → contain → document.**

---

## Playbook A — Port Scan Alert (`port_scan_detection.spl`)

**Trigger:** source IP touches 15+ distinct ports on the victim host within 60s, mostly blocked.

| Step | Action |
|---|---|
| 1. Triage | Confirm it's not expected internal tooling (vuln scanner, monitoring). Check `src` against your asset inventory / known-scanner allowlist. |
| 2. Scope | `index=linux_victim src=<ip> \| stats count by dest, dest_port, action` — did any port return `open`/`allowed`? That's the real risk, not the scan itself. |
| 3. Correlate | Run `correlated_recon_to_bruteforce.spl` — did this IP follow up with a login attempt? |
| 4. Contain | If unauthorized and external: block `src` at the firewall/NSG. If internal/lab: note and tune the allowlist. |
| 5. Document | Record: source IP, first/last seen, ports touched, whether any succeeded, action taken, ATT&CK T1046. |

## Playbook B — SSH Brute Force Alert (`ssh_bruteforce_detection.spl`)

**Trigger:** 5+ failed SSH logins, same user + source, within 5 minutes.

| Step | Action |
|---|---|
| 1. Triage | Pull the companion search — did the failures end in an `Accepted password`? That changes this from "noisy" to "critical" immediately. |
| 2. Scope | `index=linux_victim user=<user> \| stats count by action, src` across a wider window — is this one source or distributed (credential-stuffing botnet pattern)? |
| 3. Contain | Lock or reset the targeted account. If a session was established, pull `last -i` / `w` on the victim and check `index=linux_victim sourcetype=linux_secure user=<user> action=success` for the session start, then isolate the host if post-auth activity looks malicious. |
| 4. Eradicate | Rotate credentials, review `~/.ssh/authorized_keys` for persistence, check `sudo` log (`/var/log/auth.log` "COMMAND=") for anything run during the session. |
| 5. Document | Source IP(s), targeted account(s), success/fail, actions taken, ATT&CK T1110.001. |

## Playbook C — Entra ID Risky / Impossible-Travel Sign-In

**Trigger:** `entra_risky_signin.spl` or `entra_impossible_travel.spl` fires.

| Step | Action |
|---|---|
| 1. Triage | Check `riskLevelDuringSignIn` and `riskState` in Entra Identity Protection — is it already auto-remediated (MFA challenge passed = lower concern) or still open? |
| 2. Scope | Pull the user's last 10 sign-ins: `index=entra_id userPrincipalName=<user> \| table _time, ipAddress, City, Country, status.errorCode, conditionalAccessStatus`. |
| 3. Contain | If confirmed malicious: `Entra admin center → Identity Protection → Risky users → Confirm compromised`, force password reset, revoke refresh tokens (`Revoke sessions`). |
| 4. Document | User, risk level, IPs/locations involved, whether Conditional Access blocked it, action taken, ATT&CK T1078.004. |

---

## Reporting template (use for every alert you close)

```
Incident ID:
Date/Time (UTC):
Detection triggered:
ATT&CK Technique(s):
Source (IP/user):
Target (host/account):
Severity:
Summary of activity:
Actions taken:
False positive? (Y/N) — if yes, tuning recommendation:
Analyst:
```

Keep closed incidents in a `case-notes/` folder (gitignored by default, since it may contain lab IPs/usernames) so you can reference the pattern in future interviews.
