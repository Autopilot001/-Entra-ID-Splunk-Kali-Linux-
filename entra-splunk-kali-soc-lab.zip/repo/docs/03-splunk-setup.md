# 03 — Splunk Setup

## 1. Install Splunk Enterprise
- Download the free Developer license version from splunk.com for your OS (Linux recommended for the SIEM VM).
- `sudo dpkg -i splunk-*.deb` (Debian/Ubuntu) → `sudo /opt/splunk/bin/splunk start --accept-license`
- Web UI: `https://<splunk-host>:8000`

## 2. Create indexes
```
Settings → Indexes → New Index
  entra_id      (for Entra sign-in/audit logs)
  linux_victim  (for victim auth/firewall/web logs)
  kali_recon    (optional — if you forward nmap output as structured logs)
```

## 3. Install add-ons / technology add-ons (TAs)
- **Splunk Add-on for Microsoft Cloud Services** — ingests Entra ID sign-in & audit logs.
- **Splunk Add-on for Unix and Linux** — parses `auth.log`, `syslog`, `ufw.log` with correct CIM field extraction.
- **Splunk Common Information Model (CIM) Add-on** — normalizes fields (`src`, `dest`, `user`, `action`) so your SPL works across sources.

## 4. Deploy the Universal Forwarder on the victim VM
```bash
# On the victim (Ubuntu) VM
wget -O splunkforwarder.deb "https://download.splunk.com/..."
sudo dpkg -i splunkforwarder.deb
sudo /opt/splunkforwarder/bin/splunk start --accept-license
sudo /opt/splunkforwarder/bin/splunk add forward-server <splunk-ip>:9997
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/auth.log -index linux_victim
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/ufw.log -index linux_victim
sudo /opt/splunkforwarder/bin/splunk add monitor /var/log/syslog -index linux_victim
```

## 5. Enable the victim's firewall logging (for the port-scan detection)
```bash
sudo ufw logging on
sudo ufw enable
# or, if using iptables directly:
sudo iptables -A INPUT -j LOG --log-prefix "IPTABLES-DROP: " --log-level 4
```

## 6. Verify data is landing
```spl
index=entra_id | head 20
index=linux_victim | head 20
```
If `index=entra_id` is empty, double-check the Graph API app registration permissions and that admin consent was granted.

## 7. Field extraction sanity check
```spl
index=linux_victim sourcetype=linux_secure
| table _time, user, src, action
| head 20
```
If `user`/`src`/`action` aren't populating, confirm the CIM Add-on and the Unix/Linux TA are both enabled and that `props.conf`/`transforms.conf` from the TA are being applied (`btool props list linux_secure --debug`).

Next: [`04-kali-recon.md`](./04-kali-recon.md)
