# 04 — Kali Linux Reconnaissance (generating attack telemetry)

> **Scope reminder:** run every command in this file only against `192.168.56.20` (your own lab victim VM) on the host-only network. Never point these at a system you don't own.

## 1. Basic host discovery
```bash
nmap -sn 192.168.56.0/24
```

## 2. Port scan sweeps (this is what your Splunk detection fires on)
```bash
# Fast top-1000-ports TCP SYN scan
sudo nmap -sS -T4 192.168.56.20 -oN scans/syn_scan.txt

# Full 65535-port scan
sudo nmap -sS -p- -T4 192.168.56.20 -oN scans/full_scan.txt

# Service/version detection on open ports
nmap -sV -p22,80,443 192.168.56.20 -oN scans/service_scan.txt

# UDP scan (noisier, slower — good for testing alert thresholds)
sudo nmap -sU --top-ports 50 192.168.56.20 -oN scans/udp_scan.txt
```
A SYN scan against many ports in a short window is exactly the pattern the Splunk detection in `05-detection-engineering.md` looks for (many distinct `dest_port` values from one `src` within a small time window, each hitting a closed/filtered port and logged by `ufw`/`iptables`).

## 3. Simulated credential attack (lab only)
Use a **lab-only** low-stakes account and wordlist — never real credentials.
```bash
# Create a throwaway test account on the victim first:
#   sudo useradd -m labtest && echo "labtest:TempPass123" | sudo chpasswd

hydra -l labtest -P /usr/share/wordlists/rockyou-sample.txt ssh://192.168.56.20 -t 4
```
This generates repeated `Failed password` entries in `/var/log/auth.log` on the victim, forwarded into `linux_victim` — the raw material for a brute-force detection.

## 4. (Optional) Safe adversary emulation with Atomic Red Team
[Atomic Red Team](https://github.com/redcanaryco/atomic-red-team) runs small, documented, **non-destructive** test actions mapped to MITRE ATT&CK technique IDs (e.g., T1046 Network Service Discovery, T1110 Brute Force). It does not install malware — each "atomic" is an auditable script you can read before running. This is the legitimate way to test whether your SIEM and endpoint protection actually detect ATT&CK techniques, instead of hand-crafting evasive payloads.
```powershell
# On a Windows test VM (not covered in this repo's main lab, optional extension)
IEX (IWR 'https://raw.githubusercontent.com/redcanaryco/invoke-atomicredteam/master/install-atomicredteam.ps1' -UseBasicParsing)
Invoke-AtomicTest T1046
```

## 5. Testing AV/EDR alerting without live malware
If you want to validate that an endpoint agent (e.g., Bitdefender, Defender, CrowdStrike) actually alerts and that the alert reaches Splunk, use the **EICAR test file** — an industry-standard, harmless string that every AV engine is designed to flag as a "virus" for testing purposes:
```bash
echo 'X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*' > eicar_test.txt
```
This confirms the detection pipeline (agent → log → Splunk alert) works end-to-end, without touching real malware or AV-bypass techniques — which is out of scope for this repo (see README).

## 6. Mapping to MITRE ATT&CK
| Activity | ATT&CK Technique |
|---|---|
| Host discovery / port scanning | T1046 — Network Service Discovery |
| Hydra brute force | T1110.001 — Brute Force: Password Guessing |
| Service/version enumeration | T1592 — Gather Victim Host Information |
| EICAR / Atomic Red Team test | T1562.001 — Impair Defenses (tested defensively, not exploited) |

Next: [`05-detection-engineering.md`](./05-detection-engineering.md)
