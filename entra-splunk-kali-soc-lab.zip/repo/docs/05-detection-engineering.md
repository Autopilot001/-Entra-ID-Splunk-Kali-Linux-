# 05 — Detection Engineering

Each detection below lives as a standalone `.spl` file in `splunk/detections/` so you can paste it straight into a Splunk saved search / correlation search / alert.

## Detection 1 — Port scan detection (network recon)
**File:** `splunk/detections/port_scan_detection.spl`
**ATT&CK:** T1046
**Logic:** a single source IP hitting many distinct destination ports on one host within a short window, mostly resulting in `blocked`/`denied` firewall actions.

## Detection 2 — SSH brute force (Linux)
**File:** `splunk/detections/ssh_bruteforce_detection.spl`
**ATT&CK:** T1110.001
**Logic:** ≥5 `Failed password` events for the same user from the same source IP within 5 minutes, optionally followed by a successful login (classic "brute force then success" pattern).

## Detection 3 — Entra ID impossible travel
**File:** `splunk/detections/entra_impossible_travel.spl`
**ATT&CK:** T1078.004 (Valid Accounts: Cloud Accounts)
**Logic:** same user, two successful sign-ins from geographically distant IPs within a time window too short for real travel.

## Detection 4 — Entra ID risky sign-in + Conditional Access bypass attempt
**File:** `splunk/detections/entra_risky_signin.spl`
**ATT&CK:** T1110 / T1078
**Logic:** sign-ins flagged `riskLevelDuringSignIn=high` or repeated legacy-auth attempts blocked by Conditional Access.

## Detection 5 — Correlated multi-stage attack (recon → brute force)
**File:** `splunk/detections/correlated_recon_to_bruteforce.spl`
**Logic:** the same source IP appears in both the port-scan detection and the SSH brute-force detection within 30 minutes — i.e., recon followed by exploitation attempt against the same host. This is the "so what" detection that ties the whole lab together.

## Tuning notes
- Start thresholds loose (e.g., 10+ ports in 60s) while testing, then tighten based on your lab's actual false-positive rate.
- Use `| stats` + `| where` rather than raw `search` filters for anything with a count/threshold — it's far more efficient at scale.
- Every detection should resolve to a real field name validated against the CIM (`src`, `dest`, `dest_port`, `user`, `action`), not raw per-vendor field names, so detections port across data sources with minimal changes.

Next: [`06-incident-response-playbook.md`](./06-incident-response-playbook.md)
