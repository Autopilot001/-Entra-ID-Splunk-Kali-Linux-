# 02 — Microsoft Entra ID Setup

## 1. Get a tenant
- Sign up for a free [Microsoft 365 E5 developer tenant](https://developer.microsoft.com/microsoft-365/dev-program) — it includes Entra ID P2, which unlocks Identity Protection and Conditional Access risk policies.

## 2. Create test users and groups
- `Entra admin center → Identity → Users → New user`
- Create 3–5 users (e.g., `analyst1`, `finance1`, `admin1`) and a group `SOC-Lab-Users`.

## 3. Enable sign-in and audit logging
- `Identity → Monitoring & health → Sign-in logs` and `Audit logs` are enabled by default for 30 days.
- To get them into Splunk continuously, you have two options:

### Option A — Direct via Microsoft Graph / Log Analytics (recommended)
1. Route Entra ID logs to a **Log Analytics workspace** (`Entra ID → Diagnostic settings → Add diagnostic setting`, check "SignInLogs" and "AuditLogs").
2. Install the **Splunk Add-on for Microsoft Cloud Services** on your Splunk instance.
3. Configure the add-on with an **Azure AD App Registration** (client ID/secret, tenant ID) that has `AuditLog.Read.All` and `Reports.Read.All` Graph permissions.
4. Point the add-on at the Log Analytics workspace or directly at the Graph `signIns` / `directoryAudits` endpoints.

### Option B — Microsoft Sentinel intermediary
If you already use Sentinel, forward its Log Analytics workspace data to Splunk using the **Splunk Add-on for Microsoft Sentinel/Log Analytics**, or export via Event Hub → Splunk HEC.

## 4. Configure Conditional Access (for realistic "blocked sign-in" events)
- `Protection → Conditional Access → New policy`
- Example policy: "Block legacy authentication" — targets all users, blocks legacy auth protocols. Generates clean block events for your detections to catch.
- Example policy: "Require MFA for all users" — generates MFA challenge/failure events.

## 5. Turn on Identity Protection risk signals (P2 feature)
- `Protection → Identity Protection → Sign-in risk policy` → set to require MFA on Medium+ risk.
- `User risk policy` → require password change on High risk.
- These produce `riskLevelDuringSignIn` and `riskState` fields that are gold for Splunk detections (impossible travel, anonymized IP, leaked credentials, etc.).

## 6. Generate test telemetry
- Log in as your test users from different browsers / a VPN exit node to create varied `location` and `ipAddress` fields.
- Deliberately fail a login 5–6 times with `analyst1` to simulate a brute-force attempt — this is what your Splunk detection in `05-detection-engineering.md` will catch.

## Key fields you'll use in Splunk later
| Field | Source | Meaning |
|---|---|---|
| `userPrincipalName` | SignInLogs | the account |
| `ipAddress` | SignInLogs | source IP |
| `status.errorCode` | SignInLogs | 0 = success, non-zero = failure (e.g., 50126 = bad password) |
| `riskLevelDuringSignIn` | SignInLogs (Identity Protection) | none/low/medium/high |
| `conditionalAccessStatus` | SignInLogs | success/failure/notApplied |
| `activityDisplayName` | AuditLogs | e.g., "Add user", "Update Conditional Access policy" |

Next: [`03-splunk-setup.md`](./03-splunk-setup.md)
